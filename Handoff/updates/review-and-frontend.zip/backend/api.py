"""HTTP surface. Owns versions, run coordination, approval and export.

Three things this layer exists to enforce.

*Version gating.* Every mutating request states the scenario and policy version
it was composed against. A mismatch is a 409, so a late click from a superseded
view cannot act on stale evidence.

*Approval is not the model's to give.* The approve endpoint re-reads the stored
validation and the reviewer verdict and refuses unless the deterministic result
passed and the reviewer allowed. It does not consult the planner's text.

*Failures are typed.* A tool error, a provider outage or a numerical failure
becomes an explicit event and a non-2xx response. Nothing here returns a
successful empty result.
"""

from __future__ import annotations

import csv
import json
import logging
import os
import re
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from dataclasses import asdict, dataclass, field, replace
from types import SimpleNamespace
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field

from backend import store as store_module
from backend.agent.llm import LLMError, Provider
from backend.agent.huggingface import HuggingFaceProvider
from backend.agent.memory import (
    TAG_BUDGET_REDUCED,
    TAG_NO_FEASIBLE_OPTION,
    TAG_OPERATOR_REJECTED,
    TAG_SECONDARY_CONFLICT,
    TAG_WINDOW_BLOCKED,
    CaseMemory,
)
from backend.agent.planner import (
    STATUS_NO_APPROVABLE_OPTION,
    STATUS_UNRESOLVED,
    UNRESOLVED_NO_CONCLUSION,
    CaseEvent,
    PlannerLimits,
    interpret_instruction,
    plan_case,
)
from backend.agent.tools import CaseSession
from backend.ingest import IngestError, epoch_spread_s, scenario_from_tles
from backend.interop import CdmError, verify_cdm, write_cdm
from backend.planning.candidates import (
    DESIGNED_PREFIX,
    Candidate,
    candidate_from_id,
)
from backend.planning.policy import STATUS_READY as DIFF_READY
from backend.planning.policy import Policy, policy_from_document
from backend.planning.verifier import MODEL_VERSION, STATUS_PASS, reconstruct
from backend.store import CapacityError, IdempotencyConflict, Store, StoreError
from backend.visualization import DEFAULT_SAMPLE_STEP_S, MIN_SAMPLE_STEP_S, build_bundle
from backend.security import APIGuard

REPO_ROOT = Path(__file__).resolve().parents[1]
SCENARIOS_DIR = REPO_ROOT / "scenarios"
SOCRATES_CSV = REPO_ROOT / "data" / "context" / "socrates_snapshot.csv"
SOCRATES_PROVENANCE = REPO_ROOT / "data" / "context" / "socrates_provenance.json"

_log = logging.getLogger("orion_west.api")

SOCRATES_MAX_ROWS = 10

# Written once so report builders never inline an escaped newline.
NEWLINE = chr(10)

# A scenario ID is interpolated into a filesystem path, so it is matched against
# this rather than sanitised. Lowercase, digits, underscore and hyphen is every
# fixture name the generator emits; anything else is not a scenario ID and is
# refused before it reaches the disk.
SCENARIO_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")

# Completed runs are kept so a late poll still finds its result, but the
# registry is in memory and a long-lived demo would otherwise grow without
# bound. Oldest finished runs are dropped first; a running one is never evicted.
MAX_TRACKED_RUNS = 200
MAX_CASES = 200

# How long a numerical comparison waits for a free CPU slot before giving up.
# Longer than the work itself by a wide margin, so the queue drains rather than
# rejecting; short enough that a genuinely wedged server still answers.
ANALYSIS_QUEUE_WAIT_S = 15.0

RUN_RUNNING = "RUNNING"
RUN_DONE = "DONE"
RUN_FAILED = "FAILED"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


# --------------------------------------------------------------------------
# Request models
# --------------------------------------------------------------------------


class VersionedRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    expected_scenario_version: int = Field(..., ge=0)
    expected_policy_version: int = Field(..., ge=0)


class CreateCaseRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    scenario_id: str = Field("primary", max_length=64)


class PlanRequest(VersionedRequest):
    instruction: str = Field("", max_length=2000)


class PolicyPreviewRequest(VersionedRequest):
    text: str = Field(..., min_length=1, max_length=2000)


class PolicyConfirmRequest(VersionedRequest):
    diff_id: str = Field(..., min_length=1, max_length=100)


class ApproveRequest(VersionedRequest):
    proposal_id: str = Field(..., min_length=1, max_length=100)
    idempotency_key: str = Field(..., min_length=1, max_length=200)


class CdmRequest(BaseModel):
    # Bounded to match the guard's 16 KiB body cap rather than advertising a
    # limit the request could never reach. A real record is around 3 KB. The
    # guard drops an oversized body before this model ever sees it; this bound
    # is the second line, for anything reaching the model another way.
    text: str = Field(..., min_length=1, max_length=16_000)


class TleIngestRequest(BaseModel):
    # Twelve three-line sets is about 2.5 KB; the cap matches the middleware's
    # body limit rather than advertising a size the request could never carry.
    text: str = Field(..., min_length=1, max_length=16_000)
    satellite_index: int = Field(0, ge=0, le=11)
    horizon_s: float = Field(21_600.0, ge=60.0, le=172_800.0, allow_inf_nan=False)


class ResetRequest(VersionedRequest):
    pass


class ManualPolicyRequest(VersionedRequest):
    max_delta_v_mps: float = Field(..., ge=0, le=1, allow_inf_nan=False)


# --------------------------------------------------------------------------
# Run registry
# --------------------------------------------------------------------------


@dataclass
class RunState:
    run_id: str
    case_id: str
    kind: str
    status: str = RUN_RUNNING
    started_at_utc: str = field(default_factory=_now)
    finished_at_utc: str = ""
    result: dict = field(default_factory=dict)
    error: str = ""
    # What the planner is doing right now, and how many steps it has taken.
    # A run that proves no option works can take the better part of a minute,
    # and an unexplained spinner for that long tells the operator nothing about
    # a process whose whole point is that its working is inspectable.
    step: str = ""
    steps_done: int = 0

    def as_dict(self) -> dict:
        return asdict(self)


class AppState:
    def __init__(
        self,
        store: Store,
        provider_factory: Callable[[], Provider],
        reviewer_factory: Callable[[], Provider] | None,
        memory: CaseMemory | None,
        scenarios_dir: Path,
        limits: PlannerLimits,
    ) -> None:
        self.store = store
        self.provider_factory = provider_factory
        self.reviewer_factory = reviewer_factory
        self.memory = memory
        self.scenarios_dir = scenarios_dir
        self.limits = limits
        self.runs: dict[str, RunState] = {}
        self.executor = ThreadPoolExecutor(max_workers=4)
        self.lock = threading.Lock()
        # Two different scarcities, which were sharing one semaphore.
        #
        # model_slots rations a paid quota. Refusing immediately is the right
        # answer there: the caller wants to know the model is busy, not to be
        # held while someone else's turn finishes.
        #
        # compute_slots rations CPU for the numerical comparison, which makes no
        # model calls at all. That work takes well under two seconds, so a short
        # wait empties the queue while an instant refusal turned several people
        # opening the page at once into several people seeing an error -- the
        # comparison is the first thing the workspace asks for.
        self.model_slots = threading.BoundedSemaphore(4)
        self.compute_slots = threading.BoundedSemaphore(8)

    def scenario_path(self, scenario_id: str) -> Path:
        """Resolve a fixture name to a file inside ``scenarios_dir``.

        Two checks, not one. The pattern rejects anything that is not a fixture
        name, and the resolved path is then confirmed to sit under the fixtures
        directory -- so neither a traversal sequence nor a symlink can turn this
        into "load an arbitrary JSON file from disk and treat it as a scenario".
        """
        if not SCENARIO_ID_RE.match(scenario_id or ""):
            raise HTTPException(404, f"unknown scenario {scenario_id!r}")

        root = self.scenarios_dir.resolve()
        for candidate in (
            root / f"{scenario_id}.json",
            root / "variants" / f"{scenario_id}.json",
        ):
            resolved = candidate.resolve()
            if resolved.is_file() and root in resolved.parents:
                return resolved
        raise HTTPException(404, f"unknown scenario {scenario_id!r}")

    def register_run(self, run: "RunState") -> None:
        with self.lock:
            active = [r for r in self.runs.values() if r.status == RUN_RUNNING]
            if any(r.case_id == run.case_id for r in active):
                raise HTTPException(409, {"error": "CASE_BUSY", "message": "This case already has an active run."})
            if len(active) >= 4:
                raise HTTPException(429, {"error": "CAPACITY", "message": "Four runs are active. Try again shortly."}, headers={"Retry-After": "5"})
            self.runs[run.run_id] = run
            if len(self.runs) > MAX_TRACKED_RUNS:
                finished = [
                    run_id
                    for run_id, tracked in self.runs.items()
                    if tracked.status != RUN_RUNNING
                ]
                for run_id in finished[: len(self.runs) - MAX_TRACKED_RUNS]:
                    del self.runs[run_id]

    def runs_for(self, case_id: str) -> list[dict]:
        with self.lock:
            return [r.as_dict() for r in self.runs.values() if r.case_id == case_id]


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------


def _default_provider_factory() -> Provider:
    return HuggingFaceProvider()


def _state(request: Request) -> AppState:
    return request.app.state.desk


def _case_or_404(state: AppState, case_id: str):
    try:
        return state.store.get_case(case_id)
    except StoreError as exc:
        raise HTTPException(404, str(exc)) from exc


def _check_versions(case_row, expected_scenario: int, expected_policy: int) -> None:
    if case_row.scenario_version != expected_scenario or case_row.policy_version != expected_policy:
        raise HTTPException(
            409,
            {
                "error": "STALE_VERSION",
                "message": (
                    "This request was composed against an older version of the case. "
                    "Reload before acting."
                ),
                "expected_scenario_version": expected_scenario,
                "actual_scenario_version": case_row.scenario_version,
                "expected_policy_version": expected_policy,
                "actual_policy_version": case_row.policy_version,
            },
        )


def _session_for(case_row, store=None) -> CaseSession:
    session = CaseSession.from_document(case_row.document, case_id=case_row.case_id)
    session.policy = case_row.policy
    session.grid_revision = case_row.grid_revision
    if store is not None:
        session.designed = _designed_from_history(store, case_row)
    return session


def _designed_from_history(store, case_row) -> list[Candidate]:
    """Burns the planner designed in an earlier run for this case.

    A designed burn exists in the planner's session and nowhere else, so a later
    request building a fresh session would not know about it -- and the one that
    matters is usually the proposal the operator is being asked to approve.
    Recovering them from the stored validations means the comparison, the
    trajectory the operator inspects, and the options table all see the same set
    of options the decision was actually made from.

    The IDs carry the whole design, so nothing has to be stored for this beyond
    the validations that were already being kept as evidence.
    """
    recovered: list[Candidate] = []
    seen: set[str] = set()
    for validation in store.validations(case_row.case_id):
        candidate_id = validation.candidate_id
        if candidate_id in seen or not candidate_id.startswith(DESIGNED_PREFIX):
            continue
        candidate = candidate_from_id(candidate_id, case_row.grid_revision)
        if candidate is not None:
            recovered.append(candidate)
            seen.add(candidate_id)
    return recovered


def _memory_tags(case_row, session: CaseSession, outcome) -> tuple[str, ...]:
    """Tags derived from what the run actually computed, never from its prose."""
    tags: list[str] = []
    primary = case_row.document.get("primary_threat_id")
    for validation in session.validations.values():
        if any(
            e.min_separation_m < case_row.policy.min_separation_m
            and e.other_object_id != primary
            for e in validation.encounters
        ):
            tags.append(TAG_SECONDARY_CONFLICT)
            break
    if outcome.status == STATUS_NO_APPROVABLE_OPTION:
        tags.append(TAG_NO_FEASIBLE_OPTION)
    if case_row.policy_version > 1:
        tags.append(TAG_BUDGET_REDUCED)
    if case_row.policy.blocked_windows:
        tags.append(TAG_WINDOW_BLOCKED)
    verdict = outcome.proposal.reviewer_verdict if outcome.proposal else None
    if verdict is not None and verdict.decision != "ALLOW":
        tags.append(TAG_OPERATOR_REJECTED)
    return tuple(dict.fromkeys(tags))


def _record_memory(state: AppState, case_row, session: CaseSession, outcome) -> None:
    """File what this run concluded, so a later case on the same scenario sees it.

    The planner already reads this table at the top of every run. Nothing was
    ever writing to it, so it could only ever return no hits -- the feature was
    inert rather than absent, which is the harder kind of gap to notice.

    What is stored is computed: the option, the clearance the verifier measured,
    and tags derived from the results. Memory still only *suggests*; the
    briefing surfaces a prior case with its ID and nothing here changes a
    policy or clears a proposal.
    """
    if state.memory is None:
        return
    proposal = outcome.proposal
    candidate_id = proposal.candidate_id if proposal else None
    validation = session.validations.get(candidate_id) if candidate_id else None
    closest = validation.closest() if validation else None

    if proposal is not None and closest is not None:
        summary = (
            f"{candidate_id} was proposed and cleared every screened object by "
            f"{closest.min_separation_m:,.1f} m."
        )
        suggestion = f"{candidate_id} cleared this geometry before."
    elif outcome.status == STATUS_NO_APPROVABLE_OPTION:
        summary = (
            f"No option in the evaluated grid cleared the {case_row.policy.min_separation_m:,.0f} m "
            f"floor under a {case_row.policy.max_delta_v_mps} m/s budget."
        )
        suggestion = (
            "The expanded grid was checked. Re-evaluate against the current policy."
            if session.widen_used else
            "Only the current grid was exhausted; other supported search options may remain."
        )
    else:
        summary = f"Run ended {outcome.status}" + (
            f" ({outcome.unresolved_reason})" if outcome.unresolved_reason else ""
        ) + "."
        suggestion = ""

    try:
        state.memory.record(
            case_id=case_row.case_id,
            scenario_id=case_row.scenario_id,
            scenario_family=case_row.scenario_id,
            outcome=outcome.status,
            summary=summary,
            tags=_memory_tags(case_row, session, outcome),
            candidate_id=candidate_id,
            detail={
                "suggestion": suggestion,
                "policy_version": case_row.policy_version,
                "validations_run": outcome.validations_run,
            },
        )
    except Exception as exc:  # noqa: BLE001
        # A memory write must never be the reason a completed run reports failure.
        _log.warning("case memory write failed: %s", exc)


def _persist_run(state: AppState, case_row, session: CaseSession, outcome, run_id: str) -> None:
    store = state.store
    store.append_events(case_row.case_id, run_id, outcome.events)
    for validation in session.validations.values():
        store.save_validation(case_row.case_id, validation)
    if outcome.proposal is not None:
        store.save_proposal(case_row.case_id, outcome.proposal)
    store.set_grid_revision(case_row.case_id, session.grid_revision, expected_policy_version=case_row.policy_version)
    _record_memory(state, case_row, session, outcome)


def _prior_cases(events: list[dict]) -> list[dict]:
    """The memory hits from the latest run that had any, newest run first.

    Read back off the event the planner already records, so there is one place
    that decides what a hit is and no second store to drift out of step.
    """
    for event in reversed(events):
        if event["event_type"] == "memory":
            cases = event.get("details", {}).get("cases") or []
            return [c for c in cases if isinstance(c, dict)]
    return []


def _snapshot(state: AppState, case_id: str) -> dict:
    store = state.store
    case_row = _case_or_404(state, case_id)
    document = case_row.document
    execution = store.execution_for_case(case_id)
    proposal = store.latest_proposal(case_id)
    events = store.events(case_id)

    return {
        "case_id": case_row.case_id,
        "parent_case_id": case_row.parent_case_id,
        "scenario_id": case_row.scenario_id,
        "scenario_version": case_row.scenario_version,
        "policy_version": case_row.policy_version,
        "grid_revision": case_row.grid_revision,
        "created_at_utc": case_row.created_at_utc,
        "scenario": {
            "description": document.get("description", ""),
            "horizon_s": document["horizon_s"],
            "epoch_utc": document["epoch_utc"],
            "satellite_id": document["satellite_id"],
            "primary_threat_id": document["primary_threat_id"],
            "objects": [
                {"object_id": o["object_id"], "name": o["name"], "kind": o["kind"]}
                for o in document["objects"]
            ],
            "known_windows": document.get("known_windows", []),
            "provenance": document["provenance"],
            "input_hash": document.get("input_hash", ""),
        },
        "policy": {
            "policy_version": case_row.policy.policy_version,
            "max_delta_v_mps": case_row.policy.max_delta_v_mps,
            "min_separation_m": case_row.policy.min_separation_m,
            "blocked_windows": [
                {"window_id": w.window_id, "label": w.label, "start_s": w.start_s, "end_s": w.end_s}
                for w in case_row.policy.blocked_windows
            ],
        },
        "pending_diff": case_row.pending_diff,
        "validations": [
            {
                "validation_id": v.validation_id,
                "scenario_version": v.scenario_version,
                "policy_version": v.policy_version,
                "candidate_id": v.candidate_id,
                "status": v.status,
                "reason_codes": list(v.reason_codes),
                "screened_objects": list(v.evaluated_object_ids),
                "encounters": [
                    {
                        "object_id": e.other_object_id,
                        "min_separation_m": e.min_separation_m,
                        "tca_s": e.tca_s,
                        "relative_speed_mps": e.relative_speed_mps,
                        "boundary_kind": e.boundary_kind,
                        "ambiguous_time": e.ambiguous_time,
                    }
                    for e in v.encounters
                ],
                "max_primary_distance_disagreement_m": v.max_primary_distance_disagreement_m,
                "primary_time_disagreement_s": v.primary_time_disagreement_s,
                "sample_step_s": v.sample_step_s,
                "method": v.method,
            }
            for v in store.validations(case_id)
        ],
        "proposal": proposal,
        "execution": asdict(execution) if execution else None,
        "events": events,
        # Prior cases the most recent run consulted. The trace already prints a
        # sentence naming them; this is the same thing typed, so the workspace
        # can link to a case instead of asking the operator to read an ID out of
        # a log line.
        "prior_cases": _prior_cases(events),
        "runs": state.runs_for(case_id),
    }


# --------------------------------------------------------------------------
# Application
# --------------------------------------------------------------------------


def create_app(
    store: Store | None = None,
    provider_factory: Callable[[], Provider] | None = None,
    reviewer_factory: Callable[[], Provider] | None = None,
    memory: CaseMemory | None = None,
    scenarios_dir: Path | None = None,
    limits: PlannerLimits | None = None,
    require_remote_token: bool = False,
) -> FastAPI:
    @asynccontextmanager
    async def lifespan(application):
        yield
        state = application.state.desk
        state.executor.shutdown(wait=True, cancel_futures=True)
        state.store.close()

    app = FastAPI(title="Orion West", version="0.1.0", lifespan=lifespan)

    @app.exception_handler(CapacityError)
    async def capacity_error(request, exc):
        return JSONResponse({"detail": {"error": "CAPACITY", "message": str(exc)}}, status_code=429)

    # Named origins only, and none at all when the frontend ships from the same
    # origin. A wildcard would let any page the operator has open spend the
    # model quota behind this API.
    from backend.config import allowed_origins

    origins = allowed_origins()
    if origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=origins,
            allow_credentials=False,
            allow_methods=["GET", "POST", "OPTIONS"],
            allow_headers=["Content-Type", "Authorization"],
            max_age=600,
        )

    access_token = os.environ.get("DESK_ACCESS_TOKEN", "").strip()
    app.add_middleware(APIGuard, token=access_token, origins=origins,
                       require_remote_token=require_remote_token)

    app.state.desk = AppState(
        store=store or Store(":memory:"),
        provider_factory=provider_factory or _default_provider_factory,
        reviewer_factory=reviewer_factory,
        memory=memory,
        scenarios_dir=scenarios_dir or SCENARIOS_DIR,
        limits=limits or PlannerLimits(),
    )

    # ---------------------------------------------------------------- cases

    @app.post("/cases", status_code=201)
    def create_case(payload: CreateCaseRequest, request: Request) -> dict:
        state = _state(request)
        path = state.scenario_path(payload.scenario_id)
        document = json.loads(path.read_text(encoding="utf-8"))
        case_row = state.store.create_case(document, policy_from_document(document), max_cases=MAX_CASES)
        return _snapshot(state, case_row.case_id)

    @app.get("/cases/{case_id}")
    def get_case(case_id: str, request: Request) -> dict:
        return _snapshot(_state(request), case_id)

    # ----------------------------------------------------------------- plan

    @app.post("/cases/{case_id}/plan", status_code=202)
    def start_plan(case_id: str, payload: PlanRequest, request: Request) -> dict:
        state = _state(request)
        case_row = _case_or_404(state, case_id)
        _check_versions(case_row, payload.expected_scenario_version, payload.expected_policy_version)
        if state.store.execution_for_case(case_id) is not None:
            raise HTTPException(409, {"error": "CASE_EXECUTED", "message": "Reset to start another simulated decision."})

        run = RunState(run_id=f"run_{uuid.uuid4().hex[:10]}", case_id=case_id, kind="plan")
        if not state.model_slots.acquire(blocking=False):
            raise HTTPException(429, {"error": "CAPACITY", "message": "The model is busy. Try again shortly."})
        try:
            state.register_run(run)
        except Exception:
            state.model_slots.release()
            raise

        def work() -> None:
            try:
                session = _session_for(case_row)
                provider = state.provider_factory()
                reviewer = state.reviewer_factory() if state.reviewer_factory else None
                def note(event) -> None:
                    # Called on this worker thread as each step completes.
                    # Assignment to two fields is atomic enough for a progress
                    # readout; a poller that catches them between writes sees a
                    # stale count next to a fresh line, which is harmless.
                    run.step = event.summary
                    run.steps_done = event.sequence

                outcome = plan_case(
                    provider,
                    session,
                    limits=state.limits,
                    memory=state.memory,
                    reviewer_provider=reviewer,
                    instruction=payload.instruction,
                    on_event=note,
                )
                if (outcome.status == STATUS_UNRESOLVED
                        and outcome.unresolved_reason == UNRESOLVED_NO_CONCLUSION
                        and session.search_result is not None):
                    # The model may stop before its allowance is exhausted.
                    # Model tool calls stay bounded. Finish the finite grid's
                    # numerical check separately, using the same independent
                    # verifier as the workspace. This can prove infeasibility,
                    # but can never invent a planner proposal or reviewer ALLOW.
                    from backend.analysis import analyze
                    audit_started = time.perf_counter()
                    checked_before = set(session.validations)
                    run.step = "Completing the independent grid check after an incomplete model investigation."
                    audit = analyze(session)
                    ruled_out = all(
                        o["validation"] is not None and o["validation"]["status"] == "BLOCK"
                        for o in audit["options"] if o["primary_qualified"]
                    )
                    audit_seconds = time.perf_counter() - audit_started
                    outcome.elapsed_s += audit_seconds
                    event = CaseEvent(
                        sequence=len(outcome.events) + 1,
                        event_type="grid_audit",
                        summary=("The independent completion check ruled out every option in this grid."
                                 if ruled_out else
                                 "The independent completion check did not establish infeasibility; a reviewed proposal is still required."),
                        duration_ms=audit_seconds * 1000,
                        details={"model_outcome": outcome.status, "candidate_count": audit["candidate_count"],
                                 "additional_validations": len(set(session.validations) - checked_before),
                                 "recommended_id": audit["recommended_id"], "all_options_ruled_out": ruled_out},
                    )
                    outcome.events.append(event)
                    note(event)
                    if ruled_out:
                        outcome.status = STATUS_NO_APPROVABLE_OPTION
                        outcome.unresolved_reason = ""
                _persist_run(state, case_row, session, outcome, run.run_id)
                run.result = {
                    "status": outcome.status,
                    "unresolved_reason": outcome.unresolved_reason,
                    "proposal_id": outcome.proposal.proposal_id if outcome.proposal else None,
                    "model_calls": outcome.model_calls,
                    "tool_calls": outcome.tool_calls,
                    "validations_run": outcome.validations_run,
                    "elapsed_s": outcome.elapsed_s,
                    "flagged_numbers": list(outcome.flagged_numbers),
                }
                run.status = RUN_DONE
            except Exception as exc:  # noqa: BLE001
                # Deliberately broad. A worker that dies on an unanticipated
                # exception would leave the run RUNNING forever, and the UI
                # would poll a case that is never coming back. Every failure
                # has to become a visible FAILED run.
                #
                # The message is written before the status, because a poller
                # that sees FAILED reads the reason in the same response.
                run.error = f"{type(exc).__name__}: {exc}"
                run.status = RUN_FAILED
            finally:
                run.finished_at_utc = _now()
                state.model_slots.release()

        state.executor.submit(work)
        return {"run_id": run.run_id, "status": run.status, "case_id": case_id}

    @app.get("/runs/{run_id}")
    def get_run(run_id: str, request: Request) -> dict:
        state = _state(request)
        with state.lock:
            run = state.runs.get(run_id)
        if run is None:
            raise HTTPException(404, f"unknown run {run_id!r}")
        return run.as_dict()

    # --------------------------------------------------------------- policy

    @app.post("/cases/{case_id}/analysis")
    def numerical_analysis(case_id: str, payload: VersionedRequest, request: Request) -> dict:
        from backend.analysis import analyze

        state = _state(request)
        case_row = _case_or_404(state, case_id)
        _check_versions(case_row, payload.expected_scenario_version, payload.expected_policy_version)
        if not state.compute_slots.acquire(timeout=ANALYSIS_QUEUE_WAIT_S):
            raise HTTPException(429, {"error": "CAPACITY", "message": "The analysis engine is busy. Try again shortly."})
        try:
            session = _session_for(case_row, state.store)
            result = analyze(session)
            _check_versions(_case_or_404(state, case_id), payload.expected_scenario_version, payload.expected_policy_version)
            # Keep what the comparison verified. These are ordinary results from
            # the same verifier, and without them a record exported from a case
            # the operator has been looking at says no screening has been run --
            # contradicting the "Verified clear" on their screen. Storing them
            # opens no approval path: approval needs a proposal, and the
            # numerical comparison never makes one.
            for validation in session.validations.values():
                state.store.save_validation(case_id, validation)
            return result
        finally:
            state.compute_slots.release()

    @app.post("/cases/{case_id}/policy-manual")
    def manual_policy(case_id: str, payload: ManualPolicyRequest, request: Request) -> dict:
        state = _state(request)
        case_row = _case_or_404(state, case_id)
        _check_versions(case_row, payload.expected_scenario_version, payload.expected_policy_version)
        if state.store.execution_for_case(case_id) is not None:
            raise HTTPException(409, {"error": "CASE_EXECUTED", "message": "Reset before changing the executed case."})
        policy = replace(case_row.policy, policy_version=case_row.policy_version + 1, max_delta_v_mps=payload.max_delta_v_mps)
        try:
            state.store.update_policy(case_id, policy, expected_policy_version=case_row.policy_version)
        except StoreError as exc:
            raise HTTPException(409, {"error": "STALE_VERSION", "message": str(exc)}) from exc
        state.store.append_events(case_id, None, [SimpleNamespace(
            event_type="OPERATOR_POLICY_CHANGE", summary="Operator set the delta-v budget directly.",
            details={"before_mps": case_row.policy.max_delta_v_mps, "after_mps": policy.max_delta_v_mps, "policy_version": policy.policy_version},
        )])
        return _snapshot(state, case_id)

    @app.post("/cases/{case_id}/policy-preview")
    def policy_preview(case_id: str, payload: PolicyPreviewRequest, request: Request) -> dict:
        state = _state(request)
        case_row = _case_or_404(state, case_id)
        _check_versions(case_row, payload.expected_scenario_version, payload.expected_policy_version)

        session = _session_for(case_row)
        if not state.model_slots.acquire(blocking=False):
            raise HTTPException(429, {"error": "CAPACITY", "message": "The model is busy. Try again shortly."})
        try:
            diff, events, model_calls = interpret_instruction(
                state.provider_factory(), session, payload.text
            )
        except LLMError as exc:
            raise HTTPException(503, {"error": "PROVIDER_ERROR", "message": str(exc)}) from exc
        finally:
            state.model_slots.release()

        state.store.append_events(case_id, None, events)
        if session.pending_diff is not None:
            state.store.set_pending_diff(
                case_id,
                {
                    "diff_id": session.pending_diff.diff_id,
                    "status": session.pending_diff.status,
                    "clarification": session.pending_diff.clarification,
                    "source_text": session.pending_diff.source_text,
                    "base_policy_version": session.pending_diff.base_policy_version,
                    "changes": [
                        {"field": c.field, "before": c.before, "after": c.after, "note": c.note}
                        for c in session.pending_diff.changes
                    ],
                    "after": {
                        "policy_version": session.pending_diff.after.policy_version,
                        "max_delta_v_mps": session.pending_diff.after.max_delta_v_mps,
                        "min_separation_m": session.pending_diff.after.min_separation_m,
                        "blocked_windows": [
                            {
                                "window_id": w.window_id,
                                "label": w.label,
                                "start_s": w.start_s,
                                "end_s": w.end_s,
                            }
                            for w in session.pending_diff.after.blocked_windows
                        ],
                    },
                },
            )

        if diff is None:
            raise HTTPException(
                422,
                {
                    "error": "NO_CHANGE_PROPOSED",
                    "message": "The instruction did not map onto a supported constraint change.",
                    "model_calls": model_calls,
                },
            )
        return {"diff": diff, "model_calls": model_calls}

    @app.post("/cases/{case_id}/policy-confirm")
    def policy_confirm(case_id: str, payload: PolicyConfirmRequest, request: Request) -> dict:
        state = _state(request)
        case_row = _case_or_404(state, case_id)
        _check_versions(case_row, payload.expected_scenario_version, payload.expected_policy_version)

        pending = case_row.pending_diff
        if pending is None or pending["diff_id"] != payload.diff_id:
            raise HTTPException(404, f"no pending policy change with id {payload.diff_id!r}")
        if pending.get("base_policy_version") != case_row.policy_version:
            raise HTTPException(409, {"error": "STALE_DIFF", "message": "Preview the change again against the current policy."})
        if pending["status"] != DIFF_READY:
            raise HTTPException(
                409,
                {
                    "error": "DIFF_NOT_READY",
                    "message": pending.get("clarification", "The change needs clarification."),
                },
            )

        after = pending["after"]
        from backend.planning.policy import BurnWindow

        new_policy = Policy(
            policy_version=case_row.policy_version + 1,
            max_delta_v_mps=float(after["max_delta_v_mps"]),
            min_separation_m=float(after["min_separation_m"]),
            blocked_windows=tuple(
                BurnWindow(
                    window_id=w["window_id"],
                    label=w["label"],
                    start_s=float(w["start_s"]),
                    end_s=float(w["end_s"]),
                )
                for w in after.get("blocked_windows", ())
            ),
        )
        try:
            state.store.update_policy(case_id, new_policy, expected_policy_version=case_row.policy_version)
        except StoreError as exc:
            raise HTTPException(409, {"error": "STALE_VERSION", "message": str(exc)}) from exc
        return {
            "case_id": case_id,
            "policy_version": new_policy.policy_version,
            "policy": {
                "max_delta_v_mps": new_policy.max_delta_v_mps,
                "min_separation_m": new_policy.min_separation_m,
                "blocked_windows": [w.window_id for w in new_policy.blocked_windows],
            },
            "invalidated_proposals": True,
            "note": (
                "Prior proposals are marked stale because they were computed under "
                "the previous policy. Plan again to get a fresh result."
            ),
        }

    # -------------------------------------------------------- visualization

    @app.get("/cases/{case_id}/visualization")
    def visualization(
        case_id: str,
        request: Request,
        candidate_ids: str = Query(..., description="Comma-separated, at most three"),
        expected_scenario_version: int = Query(...),
        expected_policy_version: int = Query(...),
        sample_step_s: float = Query(DEFAULT_SAMPLE_STEP_S, ge=MIN_SAMPLE_STEP_S, le=600.0, allow_inf_nan=False),
    ) -> dict:
        state = _state(request)
        case_row = _case_or_404(state, case_id)
        _check_versions(case_row, expected_scenario_version, expected_policy_version)

        wanted = [c.strip() for c in candidate_ids.split(",") if c.strip()]
        if not wanted:
            raise HTTPException(422, "candidate_ids must name at least one option")
        if len(wanted) > 3:
            raise HTTPException(422, "at most three variants per request")

        selected: list[Candidate] = []
        for candidate_id in wanted:
            # Grid options and burns the planner designed itself resolve the
            # same way here; a designed burn that cannot be visualised would be
            # a proposal the operator is asked to approve without seeing it.
            candidate = candidate_from_id(candidate_id, case_row.grid_revision)
            if candidate is None:
                raise HTTPException(404, f"unknown candidate_id {candidate_id!r}")
            if candidate.burn_t_s is not None and not (
                0.0 < candidate.burn_t_s < float(case_row.document["horizon_s"])
            ):
                raise HTTPException(
                    422, f"candidate {candidate_id!r} burns outside the horizon"
                )
            selected.append(candidate)

        scenario = reconstruct(case_row.document)
        return build_bundle(
            scenario=scenario,
            candidates=selected,
            case_id=case_id,
            policy_version=case_row.policy_version,
            epoch_utc=case_row.document["epoch_utc"],
            model_version=MODEL_VERSION,
            min_separation_m=case_row.policy.min_separation_m,
            sample_step_s=sample_step_s,
        )

    # -------------------------------------------------------------- approve

    @app.post("/cases/{case_id}/approve")
    def approve(case_id: str, payload: ApproveRequest, request: Request) -> dict:
        state = _state(request)
        case_row = _case_or_404(state, case_id)
        _check_versions(case_row, payload.expected_scenario_version, payload.expected_policy_version)

        try:
            proposal = state.store.get_proposal(payload.proposal_id)
        except StoreError as exc:
            raise HTTPException(404, str(exc)) from exc

        if proposal["case_id"] != case_id:
            raise HTTPException(404, "proposal does not belong to this case")

        if (
            proposal["scenario_version"] != case_row.scenario_version
            or proposal["policy_version"] != case_row.policy_version
        ):
            raise HTTPException(
                409,
                {
                    "error": "PROPOSAL_STALE",
                    "message": "The proposal was computed under a different version of the case.",
                },
            )
        if proposal.get("status") == store_module.PROPOSAL_STALE:
            raise HTTPException(409, {"error": "PROPOSAL_STALE", "message": "Proposal superseded."})

        # Re-read the deterministic result rather than trusting the proposal row.
        try:
            validation = state.store.get_validation(proposal["validation_id"])
        except StoreError as exc:
            raise HTTPException(409, {"error": "MISSING_EVIDENCE", "message": str(exc)}) from exc

        if validation.status != STATUS_PASS:
            raise HTTPException(
                409,
                {
                    "error": "NOT_VALIDATED",
                    "message": "Validation did not pass; this cannot be approved.",
                    "reason_codes": list(validation.reason_codes),
                },
            )

        verdict = proposal.get("reviewer_verdict")
        if verdict is not None and verdict.get("decision") != "ALLOW":
            raise HTTPException(
                409,
                {
                    "error": "REVIEWER_BLOCKED",
                    "message": "The safety reviewer did not allow this proposal.",
                    "decision": verdict.get("decision"),
                    "reason_codes": verdict.get("reason_codes", []),
                },
            )

        try:
            record, created = state.store.record_execution(
                case_id=case_id,
                proposal_id=payload.proposal_id,
                candidate_id=proposal["candidate_id"],
                idempotency_key=payload.idempotency_key,
            )
        except IdempotencyConflict as exc:
            raise HTTPException(409, {"error": "IDEMPOTENCY_CONFLICT", "message": str(exc)}) from exc
        except StoreError as exc:
            raise HTTPException(409, {"error": "EVIDENCE_CONFLICT", "message": str(exc)}) from exc

        return {
            "execution": asdict(record),
            "created": created,
            "note": (
                "Simulated execution only. Nothing is transmitted to any spacecraft."
            ),
        }

    # ---------------------------------------------------------------- reset

    @app.post("/cases/{case_id}/reset", status_code=201)
    def reset(case_id: str, payload: ResetRequest, request: Request) -> dict:
        state = _state(request)
        case_row = _case_or_404(state, case_id)
        _check_versions(case_row, payload.expected_scenario_version, payload.expected_policy_version)

        document = json.loads(state.scenario_path(case_row.scenario_id).read_text(encoding="utf-8"))
        fresh = state.store.create_case(
            document, policy_from_document(document), parent_case_id=case_id, max_cases=MAX_CASES
        )
        return _snapshot(state, fresh.case_id)

    # --------------------------------------------------------------- export

    @app.get("/cases/{case_id}/export")
    def export(
        case_id: str,
        request: Request,
        format: str = Query("json", pattern="^(json|markdown|cdm)$"),
    ):
        state = _state(request)
        snapshot = _snapshot(state, case_id)
        if format == "json":
            return snapshot
        if format == "cdm":
            # The raw scenario carries the state vectors the snapshot strips.
            case_row = _case_or_404(state, case_id)
            return PlainTextResponse(
                write_cdm(snapshot, case_row.document),
                media_type="text/plain; charset=utf-8",
            )
        return PlainTextResponse(
            _markdown_report(snapshot), media_type="text/markdown; charset=utf-8"
        )

    # -------------------------------------------------------------- context

    @app.get("/context/socrates")
    def socrates(request: Request) -> dict:
        if not SOCRATES_CSV.exists():
            raise HTTPException(404, "SOCRATES snapshot not present; run scripts/fetch_snapshots.py")

        with SOCRATES_CSV.open(newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))[:SOCRATES_MAX_ROWS]

        provenance = (
            json.loads(SOCRATES_PROVENANCE.read_text(encoding="utf-8"))
            if SOCRATES_PROVENANCE.exists()
            else {}
        )
        return {
            "rows": rows,
            "row_count": len(rows),
            "source_url": provenance.get("source_url", ""),
            "retrieved_at_utc": provenance.get("retrieved_at_utc", ""),
            "source_sha256": provenance.get("raw_sha256", ""),
            "note": (
                "Real published close approaches, shown as context. Not related to "
                "the simulated scenario and not an input to any computation. Served "
                "from a committed snapshot; never fetched at runtime."
            ),
        }

    @app.post("/interop/verify-cdm")
    def interop_verify_cdm(payload: CdmRequest) -> dict:
        """Read a conjunction record from another operator and recompute it.

        This is the receiving half of coordination. The sender's conclusions are
        read only so they can be checked: every figure returned is recomputed
        here, by the same verifier that gates our own proposals, from the state
        vectors in their message.
        """
        try:
            return verify_cdm(payload.text)
        except CdmError as exc:
            raise HTTPException(
                422, {"error": "CDM_UNREADABLE", "message": str(exc)}
            ) from exc

    @app.post("/ingest/tle", status_code=201)
    def ingest_tle(payload: TleIngestRequest, request: Request) -> dict:
        """Build a case from pasted catalogue elements and screen it.

        The orbits are real; the encounter is whatever the elements say. Two
        catalogue objects usually have no close approach at all, and returning
        that is the point -- a screening tool that always finds something is not
        screening.
        """
        state = _state(request)
        try:
            document = scenario_from_tles(
                payload.text,
                satellite_index=payload.satellite_index,
                horizon_s=payload.horizon_s,
            )
        except IngestError as exc:
            raise HTTPException(
                422, {"error": "TLE_UNREADABLE", "message": str(exc)}
            ) from exc

        case_row = state.store.create_case(
            document, policy_from_document(document), max_cases=MAX_CASES
        )
        snapshot = _snapshot(state, case_row.case_id)
        snapshot["ingest"] = {
            "objects": document["provenance"]["objects"],
            "epoch_spread_s": round(epoch_spread_s(payload.text), 1),
            "note": document["provenance"]["note"],
        }
        return snapshot

    @app.get("/health")
    def health() -> dict:
        from backend.config import has_model_access, planner_model

        return {
            "status": "ok",
            "model_version": MODEL_VERSION,
            "planner_model": planner_model(),
            # Surfaced so a deployment without a key is obvious from /health
            # rather than only from the first failed run.
            "model_access": has_model_access(),
            "access_token_required": bool(access_token),
        }

    # A built frontend is served from the same origin when present, so one
    # container is the whole app. Mounted last so it cannot shadow an API route.
    dist = REPO_ROOT / "frontend" / "dist"
    if dist.is_dir():
        app.mount("/assets", StaticFiles(directory=dist / "assets"), name="assets")

        @app.get("/{full_path:path}", include_in_schema=False)
        def spa(full_path: str):
            """Serve the SPA, letting the client router own unknown paths."""
            candidate = (dist / full_path).resolve()
            if full_path and candidate.is_file() and dist.resolve() in candidate.parents:
                return FileResponse(candidate)
            return FileResponse(dist / "index.html")

    return app


# --------------------------------------------------------------------------
# Markdown export
# --------------------------------------------------------------------------


def _markdown_report(snapshot: dict) -> str:
    scenario = snapshot["scenario"]
    provenance = scenario["provenance"]
    policy = snapshot["policy"]
    lines: list[str] = []

    lines.append(f"# Decision record — case {snapshot['case_id']}")
    lines.append("")
    lines.append(
        f"Scenario `{snapshot['scenario_id']}` v{snapshot['scenario_version']}, "
        f"policy v{snapshot['policy_version']}. Generated {_now()}."
    )
    lines.append("")
    lines.append("## Provenance")
    lines.append("")
    lines.append(
        f"- Seed orbit: {provenance.get('object_name')} (NORAD {provenance.get('norad_id')}), "
        f"epoch {provenance.get('tle_epoch_utc')} — real catalogue element set"
    )
    lines.append(f"- Frame: `{provenance.get('frame')}`, model `{provenance.get('model_version')}`")
    lines.append(
        f"- Conjunction geometry: **synthetic** "
        f"(`synthetic_conjunction={provenance.get('synthetic_conjunction')}`)"
    )
    lines.append(f"- Scenario input hash: `{scenario.get('input_hash', '')[:32]}`")
    lines.append("")
    lines.append("No collision probability is computed anywhere in this record.")
    lines.append("")
    lines.append("## Constraints")
    lines.append("")
    lines.append(f"- Fuel budget: {policy['max_delta_v_mps']} m/s")
    lines.append(f"- Clearance floor: {policy['min_separation_m']:,.0f} m")
    blocked = ", ".join(w["window_id"] for w in policy["blocked_windows"]) or "none"
    lines.append(f"- Blocked windows: {blocked}")
    lines.append("")

    if snapshot["validations"]:
        lines.append("## Options validated")
        lines.append("")
        lines.append("| Option | Result | Closest approach | Object | Reason |")
        lines.append("|---|---|---|---|---|")
        for validation in snapshot["validations"]:
            closest = min(
                validation["encounters"], key=lambda e: e["min_separation_m"], default=None
            )
            lines.append(
                f"| `{validation['candidate_id']}` | {validation['status']} | "
                f"{closest['min_separation_m']:,.1f} m at {closest['tca_s']:,.0f} s | "
                f"{closest['object_id']} | {', '.join(validation['reason_codes'])} |"
                if closest
                else f"| `{validation['candidate_id']}` | {validation['status']} | — | — | "
                f"{', '.join(validation['reason_codes'])} |"
            )
        lines.append("")

    proposal = snapshot.get("proposal")
    if proposal:
        lines.append("## Recommendation")
        lines.append("")
        lines.append(f"- Option: `{proposal['candidate_id']}`")
        lines.append(f"- Status: {proposal['status']}")
        lines.append(f"- Evidence: `{proposal['validation_id']}`")
        verdict = proposal.get("reviewer_verdict")
        if verdict:
            lines.append(f"- Safety reviewer: {verdict['decision']} — {verdict.get('rationale', '')}")
        if proposal.get("qualitative_rationale"):
            lines.append("")
            lines.append("> " + proposal["qualitative_rationale"].replace("\n", " "))
        lines.append("")

    execution = snapshot.get("execution")
    if execution:
        lines.append("## Execution")
        lines.append("")
        lines.append(
            f"- `{execution['execution_id']}` applied `{execution['candidate_id']}` "
            f"at {execution['executed_at_utc']} in mode **{execution['mode']}**"
        )
        lines.append("- Simulated only. Nothing was transmitted to any spacecraft.")
        lines.append("")

    lines.append("## Activity")
    lines.append("")
    for event in snapshot["events"]:
        lines.append(
            f"{event['sequence']}. **{event['event_type']}** — {event['summary']} "
            f"({event['duration_ms']:.0f} ms)"
        )
    lines.append("")
    lines.append("## Limitations")
    lines.append("")
    lines.append(
        "- Two-body dynamics with instantaneous impulses over a six-hour horizon. "
        "No drag, no oblateness, no finite burn duration, no navigation uncertainty."
    )
    lines.append(
        "- Clearance is a deterministic simulated separation against the objects in "
        "this scenario, not a catalogue-wide screen and not a probability."
    )
    lines.append("- Delta-v is a fuel proxy. No propellant mass or lifetime is modelled.")
    lines.append("")
    return "\n".join(lines)


def _default_app() -> FastAPI:
    """Module-level app for `uvicorn backend.api:app`.

    Providers are constructed lazily per run, so importing this without a key is
    fine -- the failure surfaces on the first plan as an unresolved case rather
    than as an import error.

    The reviewer is wired only when a key is present. Wiring it without one would
    make every proposal UNAVAILABLE, which blocks approval and reads as a safety
    finding rather than a missing credential.
    """
    from backend.config import (
        database_path,
        has_model_access,
        planner_model,
        reviewer_model,
    )

    return create_app(
        store=Store(database_path()),
        provider_factory=lambda: HuggingFaceProvider(model=planner_model()),
        reviewer_factory=(
            (lambda: HuggingFaceProvider(model=reviewer_model())) if has_model_access() else None
        ),
        memory=CaseMemory(database_path()) if database_path() != ":memory:" else CaseMemory(),
        require_remote_token=True,
    )


app = _default_app()
